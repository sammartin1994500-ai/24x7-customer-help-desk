Run DOWNLOAD_ALL_PHOTOS.ps1 from the project root to download all original photos here.
