import React, { useId } from "react";

/* ------------------------------------------------------------------ *
 *  Madhubani / Mithila motif library — original vector artwork.
 *  Every shape is drawn here so the invitation uses no stock art.
 * ------------------------------------------------------------------ */

export function MadhubaniBorder({ className = "", flip = false, count = 22 }) {
  const id = useId().replace(/[:]/g, "");
  const cells = Array.from({ length: count });
  return (
    <svg
      viewBox="0 0 440 26"
      preserveAspectRatio="none"
      className={className}
      aria-hidden="true"
      style={flip ? { transform: "scaleY(-1)" } : undefined}
    >
      <defs>
        <pattern id={`tri-${id}`} width="20" height="26" patternUnits="userSpaceOnUse">
          <path d="M0 26 L10 7 L20 26 Z" fill="none" stroke="currentColor" strokeWidth="1.1" />
          <path d="M5 26 L10 16 L15 26" fill="currentColor" fillOpacity="0.35" />
          <circle cx="10" cy="3.4" r="1.7" fill="currentColor" />
        </pattern>
      </defs>
      <rect x="0" y="0" width="440" height="26" fill={`url(#tri-${id})`} />
      <line x1="0" y1="25" x2="440" y2="25" stroke="currentColor" strokeWidth="1.2" />
      <line x1="0" y1="2" x2="440" y2="2" stroke="currentColor" strokeWidth="0.7" strokeOpacity="0.6" />
      {cells.slice(0, 0)}
    </svg>
  );
}

export function Aripana({ className = "", rings = 5, petals = 16 }) {
  const ringEls = [];
  for (let r = rings; r >= 1; r--) {
    const rad = r * 9;
    ringEls.push(
      <circle
        key={`c${r}`}
        cx="60"
        cy="60"
        r={rad}
        fill="none"
        stroke="currentColor"
        strokeWidth={r === rings ? 1.1 : 0.7}
        strokeOpacity={0.85 - (rings - r) * 0.1}
      />
    );
  }
  const petalEls = Array.from({ length: petals }).map((_, i) => {
    const a = (360 / petals) * i;
    return (
      <g key={`p${i}`} transform={`rotate(${a} 60 60)`}>
        <path d="M60 12 C 54 20, 54 26, 60 30 C 66 26, 66 20, 60 12 Z" fill="currentColor" fillOpacity="0.5" />
        <circle cx="60" cy="9" r="1" fill="currentColor" />
      </g>
    );
  });
  return (
    <svg viewBox="0 0 120 120" className={className} aria-hidden="true">
      <g stroke="currentColor" fill="none">
        {ringEls}
        <g transform="rotate(22.5 60 60)">{petalEls}</g>
      </g>
      <circle cx="60" cy="60" r="3.4" fill="currentColor" />
    </svg>
  );
}

export function Lotus({ className = "" }) {
  return (
    <svg viewBox="0 0 80 60" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
        <path d="M40 54 C 40 34, 34 20, 28 8" />
        <path d="M40 54 C 40 34, 46 20, 52 8" />
        <path d="M40 54 C 30 44, 18 40, 4 40 C 14 52, 26 56, 40 54 Z" fill="currentColor" fillOpacity="0.22" />
        <path d="M40 54 C 50 44, 62 40, 76 40 C 66 52, 54 56, 40 54 Z" fill="currentColor" fillOpacity="0.22" />
        <path d="M40 54 C 34 40, 30 24, 40 4 C 50 24, 46 40, 40 54 Z" fill="currentColor" fillOpacity="0.35" />
        <path d="M4 46 C 18 46, 30 48, 40 56" />
        <path d="M76 46 C 62 46, 50 48, 40 56" />
      </g>
    </svg>
  );
}

export function Peacock({ className = "", flip = false }) {
  const angles = [-64, -46, -28, -10, 10, 28, 46, 64];
  return (
    <svg
      viewBox="0 0 130 150"
      className={className}
      aria-hidden="true"
      fill="none"
      style={flip ? { transform: "scaleX(-1)" } : undefined}
    >
      <g stroke="currentColor" strokeWidth="1.3" strokeLinecap="round">
        {angles.map((a, i) => (
          <g key={i} transform={`rotate(${a} 65 108)`} opacity={0.9 - Math.abs(a) / 260}>
            <path d="M65 108 C 52 80, 48 56, 65 12" />
            <path d="M65 108 C 78 80, 82 56, 65 12" />
            <ellipse cx="65" cy="26" rx="6.5" ry="9" fill="currentColor" fillOpacity="0.18" />
            <circle cx="65" cy="26" r="2.2" fill="currentColor" fillOpacity="0.6" />
          </g>
        ))}
      </g>
      <g stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinecap="round">
        <ellipse cx="65" cy="116" rx="10" ry="15" fill="currentColor" fillOpacity="0.16" />
        <path d="M65 104 C 60 92, 56 86, 52 78" />
        <circle cx="50" cy="75" r="6" fill="currentColor" fillOpacity="0.28" />
        <path d="M45 73 L36 76 L45 79" fill="currentColor" fillOpacity="0.5" />
        <path d="M50 69 L49 62" />
        <circle cx="49" cy="60" r="1.4" fill="currentColor" />
        <path d="M52 65 L55 59" />
        <circle cx="56" cy="57.5" r="1.4" fill="currentColor" />
        <path d="M58 128 L58 141 M72 128 L72 141" />
      </g>
    </svg>
  );
}

export function TwinFish({ className = "" }) {
  return (
    <svg viewBox="0 0 140 70" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round">
        <path d="M6 35 C 26 10, 58 12, 66 35 C 58 58, 26 60, 6 35 Z" fill="currentColor" fillOpacity="0.14" />
        <path d="M6 35 L 22 24 M6 35 L 22 46" />
        <circle cx="50" cy="30" r="2" fill="currentColor" />
        <path d="M34 26 C 40 32, 40 38, 34 44" strokeWidth="1" />
        <g transform="translate(140 0) scale(-1 1)">
          <path d="M6 35 C 26 10, 58 12, 66 35 C 58 58, 26 60, 6 35 Z" fill="currentColor" fillOpacity="0.14" />
          <path d="M6 35 L 22 24 M6 35 L 22 46" />
          <circle cx="50" cy="30" r="2" fill="currentColor" />
          <path d="M34 26 C 40 32, 40 38, 34 44" strokeWidth="1" />
        </g>
      </g>
    </svg>
  );
}

export function Diya({ className = "", lit = true, flameRef }) {
  return (
    <svg viewBox="0 0 64 74" className={className} aria-hidden="true" fill="none">
      {lit && (
        <g ref={flameRef}>
          <ellipse cx="32" cy="26" rx="14" ry="16" fill="#F6C445" opacity="0.22" className="animate-halo" />
          <path d="M32 8 C 40 20, 37 30, 32 34 C 27 30, 24 20, 32 8 Z" fill="#F2B52A" className="animate-flame" />
          <path d="M32 14 C 36 22, 34 28, 32 31 C 30 28, 28 22, 32 14 Z" fill="#FFF3C4" className="animate-flame" />
        </g>
      )}
      <path d="M8 42 C 8 54, 20 62, 32 62 C 44 62, 56 54, 56 42 Z" fill="currentColor" fillOpacity="0.85" />
      <ellipse cx="32" cy="42" rx="24" ry="4.6" fill="currentColor" />
      <path d="M14 52 C 22 58, 42 58, 50 52" stroke="#8a4a12" strokeWidth="1" strokeOpacity="0.5" />
      <path d="M20 68 L 44 68" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

export function SunMoon({ className = "" }) {
  const rays = Array.from({ length: 24 });
  return (
    <svg viewBox="0 0 200 120" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1.2" strokeLinecap="round">
        {rays.map((_, i) => (
          <g key={i} transform={`rotate(${i * 15} 62 60)`}>
            <path d="M62 12 L62 4" />
          </g>
        ))}
        <circle cx="62" cy="60" r="34" fill="currentColor" fillOpacity="0.16" />
        <circle cx="62" cy="60" r="26" />
        <circle cx="62" cy="60" r="18" strokeDasharray="2 3" />
        <path d="M62 44 L62 76 M46 60 L78 60" strokeOpacity="0.5" />
      </g>
      <g stroke="currentColor" strokeWidth="1.4">
        <path d="M168 24 A 30 30 0 1 0 168 84 A 22 22 0 1 1 168 24 Z" fill="currentColor" fillOpacity="0.2" />
        {Array.from({ length: 5 }).map((_, i) => (
          <circle key={i} cx={132 + (i % 3) * 14} cy={30 + Math.floor(i / 3) * 46} r="1.6" fill="currentColor" stroke="none" />
        ))}
      </g>
    </svg>
  );
}

export function Kalash({ className = "" }) {
  return (
    <svg viewBox="0 0 70 92" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round">
        <path d="M18 34 C 10 48, 12 66, 35 72 C 58 66, 60 48, 52 34 Z" fill="currentColor" fillOpacity="0.16" />
        <path d="M18 34 C 26 29, 44 29, 52 34" />
        <path d="M22 44 C 30 50, 40 50, 48 44" strokeDasharray="2 3" strokeWidth="1" />
        <path d="M35 26 L 35 18" />
        <path d="M35 18 C 26 12, 18 14, 14 6 C 24 2, 34 8, 35 18 Z" fill="currentColor" fillOpacity="0.25" />
        <path d="M35 18 C 44 12, 52 14, 56 6 C 46 2, 36 8, 35 18 Z" fill="currentColor" fillOpacity="0.25" />
        <circle cx="35" cy="16" r="3.4" fill="currentColor" fillOpacity="0.5" />
        <path d="M24 72 L 46 72 L 44 82 L 26 82 Z" fill="currentColor" fillOpacity="0.3" />
      </g>
    </svg>
  );
}

export function KohbarSquare({ className = "" }) {
  const id = useId().replace(/[:]/g, "");
  return (
    <svg viewBox="0 0 120 120" className={className} aria-hidden="true" fill="none">
      <defs>
        <pattern id={`k-${id}`} width="12" height="12" patternUnits="userSpaceOnUse">
          <circle cx="6" cy="6" r="1.2" fill="currentColor" fillOpacity="0.6" />
        </pattern>
      </defs>
      <g stroke="currentColor" strokeWidth="1.3">
        <rect x="4" y="4" width="112" height="112" />
        <rect x="12" y="12" width="96" height="96" fill={`url(#k-${id})`} strokeOpacity="0.6" />
        <circle cx="60" cy="60" r="26" fill="currentColor" fillOpacity="0.12" />
        <path d="M60 34 C 50 48, 50 72, 60 86 C 70 72, 70 48, 60 34 Z" fill="currentColor" fillOpacity="0.28" />
        <path d="M34 60 C 48 50, 72 50, 86 60 C 72 70, 48 70, 34 60 Z" fill="currentColor" fillOpacity="0.2" />
        <circle cx="60" cy="60" r="5" fill="currentColor" fillOpacity="0.45" />
        <path d="M4 4 L12 12 M116 4 L108 12 M4 116 L12 108 M116 116 L108 108" />
      </g>
    </svg>
  );
}

export function PaisleyDivider({ className = "" }) {
  return (
    <svg viewBox="0 0 240 30" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1.2" strokeLinecap="round">
        <path d="M0 15 L84 15" strokeOpacity="0.6" />
        <path d="M156 15 L240 15" strokeOpacity="0.6" />
        <path d="M120 5 C 132 5, 138 12, 132 18 C 127 23, 118 20, 120 14 C 121 10, 126 10, 126 13" />
        <g transform="translate(240 0) scale(-1 1)">
          <path d="M120 5 C 132 5, 138 12, 132 18 C 127 23, 118 20, 120 14 C 121 10, 126 10, 126 13" />
        </g>
        <circle cx="120" cy="15" r="2.4" fill="currentColor" />
        <circle cx="98" cy="15" r="1.4" fill="currentColor" stroke="none" />
        <circle cx="142" cy="15" r="1.4" fill="currentColor" stroke="none" />
      </g>
    </svg>
  );
}

/** Intricate Madhubani artwork for the outer face of the 3D door panels. */
export function DoorPanelArt({ className = "" }) {
  const id = useId().replace(/[:]/g, "");
  return (
    <svg viewBox="0 0 200 460" className={className} preserveAspectRatio="xMidYMid slice" aria-hidden="true" fill="none">
      <defs>
        <pattern id={`d-${id}`} width="26" height="26" patternUnits="userSpaceOnUse">
          <path d="M0 26 L13 4 L26 26 Z" fill="none" stroke="currentColor" strokeWidth="0.8" strokeOpacity="0.55" />
          <circle cx="13" cy="8" r="1.1" fill="currentColor" fillOpacity="0.6" />
        </pattern>
        <linearGradient id={`g-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#7c2216" />
          <stop offset="55%" stopColor="#5e1a12" />
          <stop offset="100%" stopColor="#43120c" />
        </linearGradient>
      </defs>
      <rect width="200" height="460" fill={`url(#g-${id})`} />
      <rect x="6" y="6" width="188" height="448" fill={`url(#d-${id})`} opacity="0.5" />
      <g stroke="#E9BE5F" strokeWidth="1.6" strokeOpacity="0.9" fill="none">
        <rect x="14" y="14" width="172" height="432" rx="3" />
        <rect x="24" y="24" width="152" height="412" rx="3" strokeOpacity="0.5" />
        <path d="M100 40 L100 56" />
        <g transform="translate(46 54)">
          <circle cx="54" cy="54" r="40" strokeOpacity="0.8" />
          <circle cx="54" cy="54" r="30" strokeOpacity="0.45" strokeDasharray="3 4" />
          <path d="M54 22 C 40 40, 40 68, 54 86 C 68 68, 68 40, 54 22 Z" fill="#E9BE5F" fillOpacity="0.16" />
          <path d="M22 54 C 40 40, 68 40, 86 54 C 68 68, 40 68, 22 54 Z" fill="#E9BE5F" fillOpacity="0.12" />
          <circle cx="54" cy="54" r="7" fill="#E9BE5F" fillOpacity="0.35" />
        </g>
        <g strokeOpacity="0.75">
          <path d="M60 250 C 60 214, 84 196, 100 186 C 116 196, 140 214, 140 250" />
          <path d="M70 250 C 70 222, 88 208, 100 200 C 112 208, 130 222, 130 250" strokeOpacity="0.4" />
          <circle cx="100" cy="170" r="7" fill="#E9BE5F" fillOpacity="0.4" />
          <path d="M46 268 L154 268" />
          <path d="M46 276 L154 276" strokeOpacity="0.4" />
          <path d="M100 292 C 84 308, 84 340, 100 356 C 116 340, 116 308, 100 292 Z" fill="#E9BE5F" fillOpacity="0.14" />
          <path d="M62 324 C 84 308, 116 308, 138 324 C 116 340, 84 340, 62 324 Z" fill="#E9BE5F" fillOpacity="0.1" />
          <path d="M100 372 L100 400" strokeOpacity="0.5" />
          <circle cx="100" cy="410" r="4" fill="#E9BE5F" fillOpacity="0.6" />
        </g>
      </g>
      <g stroke="#E9BE5F" strokeOpacity="0.85" fill="none">
        <path d="M186 200 L192 214 L186 228 L180 214 Z" fill="#E9BE5F" fillOpacity="0.55" />
      </g>
    </svg>
  );
}

export function CornerFlourish({ className = "", flipX = false, flipY = false }) {
  return (
    <svg
      viewBox="0 0 80 80"
      className={className}
      aria-hidden="true"
      fill="none"
      style={{ transform: `scale(${flipX ? -1 : 1}, ${flipY ? -1 : 1})` }}
    >
      <g stroke="currentColor" strokeWidth="1.3" strokeLinecap="round">
        <path d="M4 40 C 4 18, 18 4, 40 4" />
        <path d="M12 40 C 12 22, 22 12, 40 12" strokeOpacity="0.55" />
        <path d="M28 4 C 34 12, 34 20, 26 26 C 18 20, 20 10, 28 4 Z" fill="currentColor" fillOpacity="0.2" />
        <path d="M4 28 C 12 34, 20 34, 26 26 C 20 18, 10 20, 4 28 Z" fill="currentColor" fillOpacity="0.2" />
        <circle cx="22" cy="22" r="2" fill="currentColor" stroke="none" />
      </g>
    </svg>
  );
}