import React from "react";

/** Original, self-contained Mithila-inspired bride and groom illustration. */
export default function CoupleArt({ className = "" }) {
  return (
    <svg
      viewBox="0 0 420 360"
      role="img"
      aria-label="Mithila-inspired bride and groom illustration"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
    >
      <defs>
        <linearGradient id="couple-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#F5D77E" />
          <stop offset="1" stopColor="#B87927" />
        </linearGradient>
        <linearGradient id="couple-red" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#B83B32" />
          <stop offset="1" stopColor="#76221F" />
        </linearGradient>
      </defs>
      <g stroke="#6D3024" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
        {/* decorative halo and lotus */}
        <circle cx="210" cy="154" r="130" stroke="#C58B36" strokeWidth="2" strokeDasharray="3 8" opacity=".8" />
        <circle cx="210" cy="154" r="116" stroke="#C58B36" opacity=".65" />
        {Array.from({ length: 16 }, (_, i) => (
          <path key={i} d="M210 24 C198 39 199 48 210 55 C221 48 222 39 210 24Z" fill="#D8A64E" fillOpacity=".18" transform={`rotate(${i * 22.5} 210 154)`} />
        ))}
        {/* groom turban */}
        <path d="M111 111 Q112 65 157 58 Q202 63 205 112 L193 126 L119 126Z" fill="#D7A342" />
        <path d="M116 99 Q155 79 199 99 M119 112 Q157 93 201 112" stroke="#8A4B26" />
        <path d="M155 59 Q161 39 175 32 Q178 50 166 64" fill="#B83B32" />
        <circle cx="166" cy="70" r="6" fill="#F2D27D" />
        {/* groom face */}
        <path d="M128 119 Q128 83 158 82 Q188 83 188 119 L184 153 Q177 176 158 179 Q138 176 132 153Z" fill="#D99A68" />
        <path d="M139 128 Q147 123 153 128 M165 128 Q173 123 180 128" />
        <circle cx="148" cy="132" r="2.5" fill="#43231D" stroke="none" />
        <circle cx="172" cy="132" r="2.5" fill="#43231D" stroke="none" />
        <path d="M158 135 L155 146 L161 147 M150 158 Q159 164 169 157" />
        <path d="M135 153 Q158 168 182 151" stroke="#7C2B24" strokeWidth="4" />
        {/* groom sherwani */}
        <path d="M105 276 Q108 202 132 179 L158 174 L185 180 Q208 206 212 276Z" fill="#F0D8A1" />
        <path d="M158 178 L158 276 M137 191 L158 210 L179 191" stroke="#A66B2D" />
        {[218, 235, 252].map(y => <circle key={y} cx="165" cy={y} r="2.8" fill="#A66B2D" stroke="none" />)}
        <path d="M109 220 Q88 242 99 267 M204 220 Q220 240 214 262" />
        {/* bride veil */}
        <path d="M207 112 Q211 48 267 48 Q323 54 326 124 L319 236 Q291 268 267 268 Q236 254 213 231Z" fill="#B83B32" fillOpacity=".2" />
        <path d="M207 113 Q213 47 267 48 Q322 52 326 124 L310 140 Q287 107 266 105 Q237 106 220 139Z" fill="url(#couple-red)" />
        <path d="M216 112 Q265 81 317 116 M216 126 Q267 96 319 130" stroke="#E9C36D" />
        {/* bride face */}
        <path d="M232 119 Q232 84 267 82 Q300 84 300 120 L295 158 Q287 180 266 182 Q245 178 237 157Z" fill="#D99A68" />
        <path d="M241 128 Q249 122 256 128 M277 128 Q285 122 292 128" />
        <circle cx="249" cy="132" r="2.5" fill="#43231D" stroke="none" />
        <circle cx="284" cy="132" r="2.5" fill="#43231D" stroke="none" />
        <path d="M267 135 L264 147 L270 148 M258 159 Q267 165 277 158" />
        <circle cx="267" cy="111" r="4" fill="#D8A342" />
        <path d="M267 115 L267 126" stroke="#B52E2A" strokeWidth="3" />
        {/* bride blouse and sari */}
        <path d="M218 276 Q222 205 241 183 L266 178 L293 184 Q314 207 320 276Z" fill="#D7A342" />
        <path d="M217 208 Q263 229 314 205 L337 276 L205 276Z" fill="url(#couple-red)" />
        <path d="M218 218 Q269 240 321 216 M213 235 Q268 256 328 233" stroke="#E9C36D" />
        <path d="M242 186 L266 210 L291 186" stroke="#F4D98B" />
        {/* joined hands */}
        <path d="M183 211 Q199 196 214 212 L232 229 Q239 237 231 244 Q224 250 216 242 L197 229 Q187 240 177 231 Q169 222 183 211Z" fill="#D99A68" />
        <path d="M213 213 Q225 205 237 218 L247 229 Q253 237 245 243 Q238 248 231 241" fill="#D99A68" />
        {/* jewelry and floral details */}
        <path d="M236 177 Q266 196 296 177" stroke="#D8A342" strokeWidth="5" />
        <path d="M132 179 Q158 197 184 179" stroke="#D8A342" strokeWidth="4" />
        <circle cx="267" cy="192" r="4" fill="#F5D77E" />
        <circle cx="158" cy="194" r="3" fill="#F5D77E" />
      </g>
      {/* lotus base */}
      <g stroke="#A45A34" strokeWidth="2" fill="#DFAE5B" fillOpacity=".25">
        <path d="M120 302 Q155 276 210 300 Q265 276 300 302 Q256 333 210 318 Q164 333 120 302Z" />
        <path d="M160 306 Q180 277 210 299 Q240 277 260 306 Q236 324 210 316 Q184 324 160 306Z" />
        <path d="M210 300 Q195 278 210 263 Q225 278 210 300Z" />
      </g>
      <g fill="#B87927">
        {[[88,92],[332,92],[92,190],[328,190],[125,44],[295,44],[210,18],[210,340]].map(([x,y],i) => <circle key={i} cx={x} cy={y} r="3" />)}
      </g>
    </svg>
  );
}
