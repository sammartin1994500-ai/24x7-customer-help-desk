import React, { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";

const KEY = "mithila-invitation-motion";

export default function MotionToggle({ tone = "light" }) {
  const [calm, setCalm] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(KEY) === "calm";
    setCalm(stored);
    document.documentElement.classList.toggle("reduce-motion", stored);
  }, []);

  const toggle = () => {
    const next = !calm;
    setCalm(next);
    document.documentElement.classList.toggle("reduce-motion", next);
    localStorage.setItem(KEY, next ? "calm" : "full");
  };

  const color = tone === "dark" ? "text-paper/40 hover:text-paper/80" : "text-maroon/45 hover:text-maroon/80";

  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={calm}
      className={`inline-flex items-center gap-1.5 font-display text-[9px] uppercase tracking-[0.26em] transition ${color}`}
    >
      <Sparkles className="h-3 w-3" />
      {calm ? "Motion off" : "Motion on"}
    </button>
  );
}