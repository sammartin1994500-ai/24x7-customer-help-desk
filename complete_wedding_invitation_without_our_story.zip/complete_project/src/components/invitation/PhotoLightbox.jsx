import React, { useEffect } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { Image } from "@/components/ui/image";

export default function PhotoLightbox({ items, index, onClose, onIndexChange }) {
  const open = index !== null && items.length > 0;

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onIndexChange((index + 1) % items.length);
      if (e.key === "ArrowLeft") onIndexChange((index - 1 + items.length) % items.length);
    };
    window.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, index, items.length, onClose, onIndexChange]);

  if (!open) return null;
  const item = items[index];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Photograph"
      className="fixed inset-0 z-[60] flex items-center justify-center bg-[#1b0805]/94 px-3 py-14 backdrop-blur-sm"
      onClick={onClose}
    >
      <button
        type="button"
        onClick={onClose}
        aria-label="Close"
        className="absolute right-4 top-4 rounded-full border border-gold/40 p-2.5 text-paper/85 transition hover:bg-paper/10"
      >
        <X className="h-5 w-5" />
      </button>

      <button
        type="button"
        aria-label="Previous photograph"
        onClick={(e) => {
          e.stopPropagation();
          onIndexChange((index - 1 + items.length) % items.length);
        }}
        className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full border border-gold/40 bg-[#1b0805]/60 p-2.5 text-paper/85 transition hover:bg-paper/10 sm:left-6"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <figure
        className="relative max-h-[80vh] w-full max-w-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex h-[64vh] w-full items-center justify-center overflow-hidden rounded-xl border border-gold/40 bg-[#120604] shadow-[0_40px_100px_-30px_rgba(0,0,0,0.9)]">
          <Image
            src={item.file_url}
            alt={item.caption || "Wedding photograph"}
            className="h-full w-full"
            fittingType="fit"
          />
        </div>
        <figcaption className="mt-3 flex items-center justify-between gap-4 text-center font-display text-[10px] uppercase tracking-[0.3em] text-paper/60">
          <span>{item.caption || "Shanti & Ankit"}</span>
          <span>
            {index + 1} / {items.length}
          </span>
        </figcaption>
      </figure>

      <button
        type="button"
        aria-label="Next photograph"
        onClick={(e) => {
          e.stopPropagation();
          onIndexChange((index + 1) % items.length);
        }}
        className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full border border-gold/40 bg-[#1b0805]/60 p-2.5 text-paper/85 transition hover:bg-paper/10 sm:right-6"
      >
        <ChevronRight className="h-5 w-5" />
      </button>
    </div>
  );
}