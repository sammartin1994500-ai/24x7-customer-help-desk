import localPhotos from "./photo-local.json";
const db = globalThis.__B44_DB__ || {
  app: { getPublicSettings: async () => ({ id: "local-preview", public_settings: {} }) },
  auth: {
    isAuthenticated: async () => false,
    me: async () => null,
    logout: () => {},
    redirectToLogin: () => { console.warn("Base44 login is unavailable in local preview."); },
  },
  entities: new Proxy({}, {
    get: () => ({
      filter: async () => [],
      list: async () => [],
      get: async () => null,
      create: async (value = {}) => ({ ...value, id: "local-preview" }),
      update: async (_id, value = {}) => value,
      delete: async () => ({}),
      subscribe: () => () => {},
    }),
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: "" }) } },
};

/**
 * Original Mithila artwork created for this invitation.
 * Each key can be replaced from the admin studio (Media tab).
 */
export const ART = {
  temple:
    "https://media.base44.com/images/public/6af4f38adb46dcd54314a5bb/47b3169c8_generated_7bb2bedb.png",
  mandap:
    "https://media.base44.com/images/public/6af4f38adb46dcd54314a5bb/ef9ba6f6f_generated_d20ba53a.png",
  pond:
    "https://media.base44.com/images/public/6af4f38adb46dcd54314a5bb/e3c287286_generated_dd1119e2.png",
  sunrise:
    "https://media.base44.com/images/public/6af4f38adb46dcd54314a5bb/69b0e9b5a_generated_67831cec.png",
};

export const MEDIA_KEYS = [
  { key: "temple", label: "Temple gateway (opening)" },
  { key: "sunrise", label: "Mithila sunrise" },
  { key: "mandap", label: "Wedding mandap" },
  { key: "couple", label: "Bride & groom illustration" },
  { key: "kohbar", label: "Kohbar artwork" },
  { key: "pond", label: "Lotus pond at dusk" },
];

export function artFor(key, overrides) {
  const localFiles = { temple: "decor-03.png", sunrise: "decor-02.png", mandap: "decor-01.png", pond: "decor-04.png" };
  const filename = localFiles[key];
  return (overrides && overrides[key]) || (filename && localPhotos[filename] ? `/images/${filename}` : null) || ART[key] || ART.temple;
}