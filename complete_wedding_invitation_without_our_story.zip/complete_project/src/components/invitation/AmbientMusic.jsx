import React, { useEffect, useRef, useState } from "react";
import { Music, Pause } from "lucide-react";

/** Floating background-music control. Only appears when the family uploads a track. */
export default function AmbientMusic({ src, title }) {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = 0.35;
  }, [src]);

  if (!src) return null;

  const toggle = async () => {
    const el = audioRef.current;
    if (!el) return;
    try {
      if (playing) {
        el.pause();
        setPlaying(false);
      } else {
        await el.play();
        setPlaying(true);
      }
    } catch {
      setPlaying(false);
    }
  };

  return (
    <div className="fixed bottom-5 right-4 z-40">
      <audio ref={audioRef} src={src} loop preload="none" />
      <button
        type="button"
        onClick={toggle}
        aria-label={playing ? "Pause background music" : "Play background music"}
        className="group flex items-center gap-2 rounded-full border border-gold/50 bg-paper/90 py-2 pl-2 pr-4 shadow-[0_14px_30px_-18px_rgba(59,22,16,0.9)] backdrop-blur transition hover:bg-paper"
      >
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-sindoor/10 text-sindoor">
          {playing ? <Pause className="h-3.5 w-3.5" /> : <Music className="h-3.5 w-3.5" />}
        </span>
        <span className="font-display text-[9px] uppercase tracking-[0.22em] text-maroon/70">
          {playing ? "Playing" : title || "Music"}
        </span>
        {playing && (
          <span className="flex items-end gap-[2px]" aria-hidden="true">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="animate-soft-float h-3 w-[2px] rounded-full bg-sindoor/60"
                style={{ animationDelay: `${i * 0.18}s` }}
              />
            ))}
          </span>
        )}
      </button>
    </div>
  );
}