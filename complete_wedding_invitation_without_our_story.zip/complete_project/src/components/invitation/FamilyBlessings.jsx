import React from "react";
import { MapPin } from "lucide-react";
import {
  CornerFlourish,
  KohbarSquare,
  Lotus,
  MadhubaniBorder,
  PaisleyDivider,
  Aripana,
} from "@/components/mithila/Motifs";
import Reveal from "./Reveal";

function FamilyPanel({ family, accent }) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-gold/50 card-paper px-6 py-8 sm:px-9 sm:py-10">
      <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 text-gold/25">
        <KohbarSquare className="h-full w-full" />
      </div>
      <div className="pointer-events-none absolute inset-x-0 top-0 text-sindoor/50">
        <MadhubaniBorder className="h-3.5 w-full" />
      </div>
      <CornerFlourish className="pointer-events-none absolute bottom-2 left-2 h-12 w-12 text-gold/50" />
      <CornerFlourish flipX className="pointer-events-none absolute bottom-2 right-2 h-12 w-12 text-gold/50" />

      <div className="relative text-center">
        <p className="eyebrow">{family.subtitle}</p>
        <h3
          className="mt-2 font-heading text-[clamp(1.4rem,4vw,1.9rem)]"
          style={{ color: accent }}
        >
          {family.title}
        </h3>
        <PaisleyDivider className="mx-auto my-3 h-5 w-40 text-gold/70" />
      </div>

      <ul className="relative mt-2 divide-y divide-gold/20">
        {(family.members || []).map((m, i) => (
          <li key={`${m.name}-${i}`} className="flex items-baseline justify-between gap-4 py-2.5">
            <span className="font-display text-[10px] uppercase tracking-[0.22em] text-maroon/50">
              {m.relation}
            </span>
            <span className="text-right font-heading text-[15px] text-maroon sm:text-base">
              {m.name}
            </span>
          </li>
        ))}
      </ul>

      <div className="relative mt-5 flex items-center justify-center gap-1.5 text-maroon/60">
        <MapPin className="h-3.5 w-3.5 text-sindoor/70" />
        <span className="font-display text-[10.5px] uppercase tracking-[0.2em]">{family.location}</span>
      </div>
    </div>
  );
}

export default function FamilyBlessings({ data }) {
  return (
    <section id="blessings" className="relative overflow-hidden bg-[hsl(var(--paper-deep))]/60 px-5 py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0">
        <Aripana className="absolute left-1/2 top-6 h-[420px] w-[420px] -translate-x-1/2 text-gold/12" />
      </div>

      <div className="relative mx-auto max-w-5xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">Blessings</p>
          <h2 className="mt-3 font-heading text-[clamp(1.8rem,5vw,2.9rem)] leading-tight text-maroon">
            {data.blessing_heading}
          </h2>
          <PaisleyDivider className="mx-auto my-5 h-6 w-48 text-gold/70" />
          <p className="text-[15px] leading-relaxed text-maroon/70">{data.blessing_intro}</p>
        </Reveal>

        <div className="relative mt-12 grid gap-6 md:grid-cols-[1fr_auto_1fr] md:items-center md:gap-4">
          <Reveal>
            <FamilyPanel family={data.bride_family} accent="hsl(var(--sindoor))" />
          </Reveal>

          <div className="flex items-center justify-center md:flex-col md:gap-4">
            <span className="hidden h-16 w-px bg-gradient-to-b from-transparent via-gold/60 to-transparent md:block" />
            <Lotus className="h-8 w-11 text-gold/80" />
            <span className="hidden h-16 w-px bg-gradient-to-b from-transparent via-gold/60 to-transparent md:block" />
          </div>

          <Reveal delay={120}>
            <FamilyPanel family={data.groom_family} accent="hsl(var(--leaf))" />
          </Reveal>
        </div>
      </div>
    </section>
  );
}