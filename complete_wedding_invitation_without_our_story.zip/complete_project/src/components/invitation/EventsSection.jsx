import React from "react";
import { MapPin, Clock, CalendarDays, ArrowUpRight } from "lucide-react";
import { MadhubaniBorder, PaisleyDivider, CornerFlourish, TwinFish } from "@/components/mithila/Motifs";
import { eventIcons } from "./EventIcons";
import { ART } from "./artAssets";
import { Image } from "@/components/ui/image";
import Reveal from "./Reveal";

const TONES = {
  sangeet: { ink: "#9a5a12", wash: "rgba(240,169,59,0.13)", ring: "rgba(240,169,59,0.5)" },
  haldi: { ink: "#a87708", wash: "rgba(240,180,41,0.16)", ring: "rgba(240,180,41,0.55)" },
  mehendi: { ink: "hsl(var(--leaf))", wash: "rgba(45,90,39,0.10)", ring: "rgba(45,90,39,0.35)" },
  vivah: { ink: "hsl(var(--sindoor))", wash: "rgba(184,42,29,0.10)", ring: "rgba(184,42,29,0.4)" },
};

function EventCard({ event, index }) {
  const Icon = eventIcons[event.icon] || eventIcons.sangeet;
  const tone = TONES[event.key] || TONES.sangeet;
  return (
    <Reveal delay={index * 90}>
      <article
        className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-gold/40 px-6 pb-6 pt-7 transition-transform duration-500 hover:-translate-y-1"
        style={{ background: `linear-gradient(165deg, rgba(253,246,227,0.96), ${tone.wash})` }}
      >
        <CornerFlourish className="pointer-events-none absolute left-1.5 top-1.5 h-8 w-8 text-gold/40" />
        <CornerFlourish flipX className="pointer-events-none absolute right-1.5 top-1.5 h-8 w-8 text-gold/40" />
        <div className="mx-auto" style={{ color: tone.ink }}>
          <Icon className="h-16 w-16 transition-transform duration-700 group-hover:scale-105" />
        </div>
        <h3 className="mt-2 text-center font-heading text-[clamp(1.3rem,3.4vw,1.6rem)]" style={{ color: tone.ink }}>
          {event.name}
        </h3>
        <p className="mt-1 text-center font-display text-[10px] uppercase tracking-[0.28em] text-maroon/55">
          {event.date_label}
        </p>
        <p className="mt-0.5 text-center font-heading text-[15px] text-maroon">{event.time_label}</p>
        <div className="my-4 h-px w-full" style={{ background: `linear-gradient(90deg,transparent,${tone.ring},transparent)` }} />
        <p className="text-center text-[13.5px] leading-relaxed text-maroon/70">{event.note}</p>
        <div className="mt-auto pt-5 text-center">
          <p className="inline-flex items-center gap-1.5 font-display text-[10px] uppercase tracking-[0.18em] text-maroon/55">
            <MapPin className="h-3 w-3" /> {event.venue}
          </p>
          {event.map_url && (
            <a
              href={event.map_url}
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-flex items-center gap-1 font-display text-[10px] uppercase tracking-[0.24em] underline decoration-gold/60 underline-offset-4 transition hover:opacity-70"
              style={{ color: tone.ink }}
            >
              Directions <ArrowUpRight className="h-3 w-3" />
            </a>
          )}
        </div>
      </article>
    </Reveal>
  );
}

function VivahCard({ event }) {
  return (
    <Reveal>
      <article className="relative mt-8 overflow-hidden rounded-3xl border border-gold/50 shadow-[0_40px_90px_-40px_rgba(59,22,16,0.8)]">
        <Image
          src={ART.mandap}
          alt="Wedding mandap with marigold and brass diyas"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-[linear-gradient(100deg,rgba(42,13,8,0.92)_0%,rgba(42,13,8,0.72)_46%,rgba(94,26,18,0.42)_100%)]" />
        <div className="absolute inset-x-0 top-0 text-[#E9BE5F]/70">
          <MadhubaniBorder className="h-4 w-full" />
        </div>

        <div className="relative px-6 py-12 sm:px-12 sm:py-16">
          <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="max-w-xl">
              <p className="font-display text-[10px] uppercase tracking-[0.4em] text-[#E9BE5F]">
                The Wedding · Shubh Muhurat
              </p>
              <h3 className="mt-2 font-heading text-[clamp(2.4rem,8vw,4.2rem)] leading-none text-paper">
                {event.name}
              </h3>
              <PaisleyDivider className="my-4 h-6 w-44 text-[#E9BE5F]/80" />
              <p className="font-heading text-lg text-paper/95">{event.date_label}</p>
              <p className="mt-1 inline-flex items-center gap-2 rounded-full border border-[#E9BE5F]/40 px-3 py-1 font-display text-[10px] uppercase tracking-[0.26em] text-[#F6E4B4]">
                <Clock className="h-3 w-3" /> {event.time_label}
              </p>
              <p className="mt-4 max-w-md text-[14px] leading-relaxed text-paper/75">{event.note}</p>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-1.5 font-display text-[10px] uppercase tracking-[0.22em] text-paper/70">
                  <MapPin className="h-3.5 w-3.5 text-[#E9BE5F]" /> {event.venue}
                </span>
                {event.map_url && (
                  <a
                    href={event.map_url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-full border border-[#E9BE5F]/60 px-4 py-1.5 font-display text-[10px] uppercase tracking-[0.24em] text-[#F6E4B4] transition hover:bg-[#E9BE5F]/15"
                  >
                    Get Directions <ArrowUpRight className="h-3 w-3" />
                  </a>
                )}
              </div>
            </div>

            <div className="hidden shrink-0 sm:block">
              <div className="relative flex h-40 w-40 items-center justify-center rounded-full border border-[#E9BE5F]/40">
                <div className="absolute inset-3 rounded-full border border-[#E9BE5F]/25" />
                <div className="text-center">
                  <p className="font-display text-[9px] uppercase tracking-[0.3em] text-[#E9BE5F]">Vivah</p>
                  <p className="font-heading text-4xl text-paper">30</p>
                  <p className="font-display text-[9px] uppercase tracking-[0.3em] text-paper/70">Nov 2026</p>
                </div>
                <div className="absolute -inset-1 animate-open-glow rounded-full bg-[radial-gradient(circle,rgba(233,190,95,0.28),transparent_70%)]" />
              </div>
            </div>
          </div>

          <TwinFish className="mt-8 h-7 w-16 text-[#E9BE5F]/60" />
        </div>
      </article>
    </Reveal>
  );
}

export default function EventsSection({ data }) {
  const events = data.events || [];
  const vivah = events.find((e) => e.key === "vivah") || events[events.length - 1];
  const others = events.filter((e) => e !== vivah);

  return (
    <section id="events" className="relative overflow-hidden px-5 py-20 sm:py-28">
      <div className="relative mx-auto max-w-6xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">The Celebrations</p>
          <h2 className="mt-3 font-heading text-[clamp(1.8rem,5vw,2.9rem)] leading-tight text-maroon">
            {data.events_heading}
          </h2>
          <PaisleyDivider className="mx-auto my-5 h-6 w-48 text-gold/70" />
          <p className="text-[15px] leading-relaxed text-maroon/70">{data.events_intro}</p>
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {others.map((event, i) => (
            <EventCard key={event.key || i} event={event} index={i} />
          ))}
        </div>

        {vivah && <VivahCard event={vivah} />}

        <p className="mt-6 flex items-center justify-center gap-2 text-center font-display text-[10px] uppercase tracking-[0.24em] text-maroon/45">
          <CalendarDays className="h-3.5 w-3.5" /> All timings are Indian Standard Time
        </p>
      </div>
    </section>
  );
}