import React from "react";

export function Panel({ title, description, children, action }) {
  return (
    <section className="rounded-2xl border border-gold/35 bg-card/80 p-5 shadow-[0_20px_50px_-40px_rgba(59,22,16,0.6)] sm:p-7">
      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-heading text-xl text-maroon">{title}</h2>
          {description && <p className="mt-1 max-w-xl text-[13px] leading-relaxed text-maroon/55">{description}</p>}
        </div>
        {action}
      </div>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

export function Field({ label, hint, children, className = "" }) {
  return (
    <label className={`block ${className}`}>
      <span className="font-display text-[9.5px] uppercase tracking-[0.24em] text-maroon/55">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-maroon/40">{hint}</span>}
    </label>
  );
}

const inputCls =
  "mt-1.5 w-full rounded-lg border border-gold/40 bg-paper/70 px-3 py-2.5 text-[14px] text-maroon placeholder:text-maroon/30 focus:border-sindoor/60 focus:outline-none focus:ring-1 focus:ring-sindoor/30";

export function TextInput({ label, hint, value, onChange, placeholder, type = "text", className }) {
  return (
    <Field label={label} hint={hint} className={className}>
      <input
        type={type}
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={inputCls}
      />
    </Field>
  );
}

export function TextArea({ label, hint, value, onChange, rows = 3, placeholder }) {
  return (
    <Field label={label} hint={hint}>
      <textarea
        rows={rows}
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`${inputCls} resize-y leading-relaxed`}
      />
    </Field>
  );
}

export function Select({ label, value, onChange, options, hint }) {
  return (
    <Field label={label} hint={hint}>
      <select value={value ?? ""} onChange={(e) => onChange(e.target.value)} className={inputCls}>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </Field>
  );
}

export function GhostButton({ children, onClick, tone = "default", type = "button", disabled }) {
  const tones = {
    default: "border-gold/50 text-maroon/70 hover:bg-gold/10",
    danger: "border-destructive/40 text-destructive hover:bg-destructive/10",
    solid: "border-transparent bg-[linear-gradient(100deg,#8f2417,#b82a1d_45%,#8f2417)] text-paper hover:-translate-y-0.5",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-1.5 rounded-full border px-4 py-2 font-display text-[9.5px] uppercase tracking-[0.22em] transition disabled:cursor-not-allowed disabled:opacity-60 ${tones[tone]}`}
    >
      {children}
    </button>
  );
}

export function SubCard({ title, onRemove, children }) {
  return (
    <div className="rounded-xl border border-gold/25 bg-paper/45 p-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="font-display text-[9.5px] uppercase tracking-[0.26em] text-sindoor/80">{title}</p>
        {onRemove && (
          <button
            type="button"
            onClick={onRemove}
            className="font-display text-[9px] uppercase tracking-[0.2em] text-destructive/70 hover:text-destructive"
          >
            Remove
          </button>
        )}
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}