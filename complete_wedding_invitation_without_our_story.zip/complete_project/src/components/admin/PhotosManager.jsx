const db = globalThis.__B44_DB__ || {
  app: { getPublicSettings: async () => ({ id: "local-preview", public_settings: {} }) },
  auth: {
    isAuthenticated: async () => false,
    me: async () => null,
    logout: () => {},
    redirectToLogin: () => { console.warn("Base44 login is unavailable in local preview."); },
  },
  entities: new Proxy({}, {
    get: () => ({
      filter: async () => [],
      list: async () => [],
      get: async () => null,
      create: async (value = {}) => ({ ...value, id: "local-preview" }),
      update: async (_id, value = {}) => value,
      delete: async () => ({}),
      subscribe: () => () => {},
    }),
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: "" }) } },
};

import React, { useRef, useState } from "react";
import { Image } from "@/components/ui/image";
import { Upload, Trash2, Loader2, Check } from "lucide-react";

import { uploadImage } from "@/lib/uploadImage";
import { Panel } from "./Fields";

function Slot({ person, slot, label, photo, onUpload, onRemove, busy }) {
  const inputRef = useRef(null);
  const [drag, setDrag] = useState(false);

  return (
    <div className="group relative">
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onUpload(file);
          e.target.value = "";
        }}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDrag(true);
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          const file = e.dataTransfer.files?.[0];
          if (file) onUpload(file);
        }}
        aria-label={`Upload ${label}`}
        className={`relative flex aspect-[3/4] w-full flex-col items-center justify-center overflow-hidden rounded-lg border transition ${
          drag ? "border-sindoor bg-sindoor/10" : "border-gold/40 bg-paper/60 hover:border-gold/70"
        }`}
      >
        {photo ? (
          <>
            <Image src={photo.file_url} alt={label} className="h-full w-full object-cover" />
            <span className="absolute inset-x-0 bottom-0 bg-maroon/70 py-1 text-center font-display text-[8px] uppercase tracking-[0.18em] text-paper opacity-0 transition group-hover:opacity-100">
              Replace
            </span>
          </>
        ) : (
          <span className="flex flex-col items-center gap-1 px-1 text-center">
            <Upload className="h-4 w-4 text-maroon/35" />
            <span className="font-display text-[8px] uppercase tracking-[0.16em] text-maroon/40">
              {slot === 0 ? "Main" : `Photo ${slot}`}
            </span>
          </span>
        )}
        {busy && (
          <span className="absolute inset-0 flex items-center justify-center bg-paper/80">
            <Loader2 className="h-4 w-4 animate-spin text-sindoor" />
          </span>
        )}
      </button>
      {photo && !busy && (
        <button
          type="button"
          onClick={onRemove}
          aria-label={`Remove ${label}`}
          className="absolute right-1 top-1 rounded-full bg-paper/90 p-1 text-destructive/80 opacity-0 shadow transition group-hover:opacity-100"
        >
          <Trash2 className="h-3 w-3" />
        </button>
      )}
    </div>
  );
}

function PersonBlock({ person, title, description, photos, onChanged }) {
  const [busy, setBusy] = useState(null);
  const [note, setNote] = useState("");

  const find = (slot) => photos.find((p) => p.person === person && p.slot === slot);

  const handleUpload = async (slot, file) => {
    setBusy(slot);
    setNote("");
    try {
      const url = await uploadImage(file);
      const existing = find(slot);
      if (existing) await db.entities.CouplePhoto.update(existing.id, { file_url: url });
      else await db.entities.CouplePhoto.create({ person, slot, file_url: url });
      setNote("Saved");
      await onChanged();
      setTimeout(() => setNote(""), 1600);
    } catch (err) {
      setNote(err?.message || "Upload failed");
    }
    setBusy(null);
  };

  const handleRemove = async (slot) => {
    const existing = find(slot);
    if (!existing) return;
    setBusy(slot);
    await db.entities.CouplePhoto.delete(existing.id);
    await onChanged();
    setBusy(null);
  };

  const filled = Array.from({ length: 11 }).filter((_, s) => find(s)).length;

  return (
    <Panel
      title={title}
      description={description}
      action={
        <span className="flex items-center gap-2 rounded-full border border-gold/40 px-3 py-1 font-display text-[9px] uppercase tracking-[0.2em] text-maroon/55">
          {note === "Saved" ? <Check className="h-3 w-3 text-leaf" /> : null}
          {note || `${filled} of 11 added`}
        </span>
      }
    >
      <div>
        <p className="mb-2 font-display text-[9px] uppercase tracking-[0.24em] text-sindoor/80">Main Portrait</p>
        <div className="w-28">
          <Slot
            person={person}
            slot={0}
            label={`${title} main portrait`}
            photo={find(0)}
            busy={busy === 0}
            onUpload={(file) => handleUpload(0, file)}
            onRemove={() => handleRemove(0)}
          />
        </div>
      </div>

      <div>
        <p className="mb-2 font-display text-[9px] uppercase tracking-[0.24em] text-sindoor/80">
          Ten Floating Photographs
        </p>
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-6 lg:grid-cols-10">
          {Array.from({ length: 10 }).map((_, i) => {
            const slot = i + 1;
            return (
              <Slot
                key={slot}
                person={person}
                slot={slot}
                label={`${title} photograph ${slot}`}
                photo={find(slot)}
                busy={busy === slot}
                onUpload={(file) => handleUpload(slot, file)}
                onRemove={() => handleRemove(slot)}
              />
            );
          })}
        </div>
      </div>
    </Panel>
  );
}

export default function PhotosManager({ photos, onChanged }) {
  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-gold/30 bg-gold/5 px-4 py-3 text-[12.5px] leading-relaxed text-maroon/65">
        Photographs are stored publicly — anyone with the link can open them, so they can appear on the invitation for
        every guest. Upload a main portrait plus exactly ten photographs for each of the couple.
      </div>

      <PersonBlock
        person="bride"
        title="Bride's Photographs"
        description="Shanti's main portrait and the ten photographs that float out when a guest taps her portrait."
        photos={photos}
        onChanged={onChanged}
      />
      <PersonBlock
        person="groom"
        title="Groom's Photographs"
        description="Ankit's main portrait and the ten photographs that float out when a guest taps his portrait."
        photos={photos}
        onChanged={onChanged}
      />
    </div>
  );
}