const db = globalThis.__B44_DB__ || {
  app: { getPublicSettings: async () => ({ id: "local-preview", public_settings: {} }) },
  auth: {
    isAuthenticated: async () => false,
    me: async () => null,
    logout: () => {},
    redirectToLogin: () => { console.warn("Base44 login is unavailable in local preview."); },
  },
  entities: new Proxy({}, {
    get: () => ({
      filter: async () => [],
      list: async () => [],
      get: async () => null,
      create: async (value = {}) => ({ ...value, id: "local-preview" }),
      update: async (_id, value = {}) => value,
      delete: async () => ({}),
      subscribe: () => () => {},
    }),
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: "" }) } },
};

import React, { useCallback, useEffect, useState } from "react";
import { Loader2, RefreshCw, Check, X, MessageSquare } from "lucide-react";

import { Panel, GhostButton } from "./Fields";

export default function RepliesPanel() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const data = await db.entities.Rsvp.list("-created_date", 300);
      setRows(Array.isArray(data) ? data : []);
    } catch (e) {
      setError(e?.message || "Could not load the replies.");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const yes = rows.filter((r) => r.attending === "yes");
  const guests = yes.reduce((sum, r) => sum + (Number(r.guest_count) || 1), 0);

  return (
    <Panel
      title="Guest Replies"
      description="Every reply sent through the invitation form."
      action={
        <GhostButton onClick={load}>
          <RefreshCw className="h-3 w-3" /> Refresh
        </GhostButton>
      }
    >
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Replies", value: rows.length },
          { label: "Attending", value: yes.length },
          { label: "Total guests", value: guests },
        ].map((s) => (
          <div key={s.label} className="rounded-xl border border-gold/30 bg-paper/50 px-3 py-3 text-center">
            <p className="font-heading text-2xl text-maroon">{s.value}</p>
            <p className="font-display text-[8.5px] uppercase tracking-[0.2em] text-maroon/50">{s.label}</p>
          </div>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center gap-2 py-6 text-[13px] text-maroon/50">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading replies…
        </div>
      ) : error ? (
        <p className="text-[13px] text-destructive">{error}</p>
      ) : rows.length === 0 ? (
        <p className="py-6 text-center text-[13px] text-maroon/50">
          No replies yet — they will appear here as guests respond.
        </p>
      ) : (
        <div className="divide-y divide-gold/15">
          {rows.map((r) => (
            <div key={r.id} className="flex flex-wrap items-start justify-between gap-2 py-3">
              <div className="min-w-0">
                <p className="font-heading text-[15px] text-maroon">{r.guest_name}</p>
                {r.message && (
                  <p className="mt-1 flex items-start gap-1.5 text-[12.5px] leading-relaxed text-maroon/55">
                    <MessageSquare className="mt-0.5 h-3 w-3 shrink-0 text-gold/70" />
                    {r.message}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span className="font-display text-[9px] uppercase tracking-[0.18em] text-maroon/45">
                  {r.guest_count || 1} {Number(r.guest_count) === 1 ? "guest" : "guests"}
                </span>
                <span
                  className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-display text-[8.5px] uppercase tracking-[0.16em] ${
                    r.attending === "yes" ? "bg-leaf/10 text-leaf" : "bg-destructive/10 text-destructive"
                  }`}
                >
                  {r.attending === "yes" ? <Check className="h-2.5 w-2.5" /> : <X className="h-2.5 w-2.5" />}
                  {r.attending === "yes" ? "Attending" : "Unable"}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
}