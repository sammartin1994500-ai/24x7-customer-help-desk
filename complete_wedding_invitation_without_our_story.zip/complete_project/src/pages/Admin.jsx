const db = globalThis.__B44_DB__ || {
  app: { getPublicSettings: async () => ({ id: "local-preview", public_settings: {} }) },
  auth: {
    isAuthenticated: async () => false,
    me: async () => null,
    logout: () => {},
    redirectToLogin: () => { console.warn("Base44 login is unavailable in local preview."); },
  },
  entities: new Proxy({}, {
    get: () => ({
      filter: async () => [],
      list: async () => [],
      get: async () => null,
      create: async (value = {}) => ({ ...value, id: "local-preview" }),
      update: async (_id, value = {}) => value,
      delete: async () => ({}),
      subscribe: () => () => {},
    }),
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: "" }) } },
};

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2, Save, ArrowLeft, LogOut, Check, ShieldAlert } from "lucide-react";

import { defaultInvitation, mergeInvitation } from "@/lib/invitationDefaults";
import { GhostButton } from "@/components/admin/Fields";
import {
  CouplePanel,
  FamiliesPanel,
  EventsPanel,
  JourneyPanel,
  StoryPanel,
  WordsPanel,
  MediaPanel,
} from "@/components/admin/ContentPanels";
import PhotosManager from "@/components/admin/PhotosManager";
import RepliesPanel from "@/components/admin/RepliesPanel";
import { Aripana, PaisleyDivider } from "@/components/mithila/Motifs";

const TABS = [
  { key: "couple", label: "Couple & Venue" },
  { key: "families", label: "Families" },
  { key: "events", label: "Celebrations" },
  { key: "journey", label: "Journey" },
  { key: "story", label: "Story" },
  { key: "words", label: "Words" },
  { key: "photos", label: "Photographs" },
  { key: "media", label: "Music & Art" },
  { key: "replies", label: "Replies" },
];

function Gate({ title, children }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-paper px-5">
      <Aripana className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 text-gold/20" />
      <div className="relative w-full max-w-md rounded-2xl border border-gold/45 card-paper px-7 py-9 text-center">
        <ShieldAlert className="mx-auto h-8 w-8 text-sindoor/70" />
        <h1 className="mt-3 font-heading text-2xl text-maroon">{title}</h1>
        <PaisleyDivider className="mx-auto my-4 h-5 w-40 text-gold/70" />
        {children}
      </div>
    </div>
  );
}

export default function Admin() {
  const [status, setStatus] = useState("loading");
  const [user, setUser] = useState(null);
  const [draft, setDraft] = useState(defaultInvitation);
  const [recordId, setRecordId] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [tab, setTab] = useState("couple");
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => {
    let alive = true;
    (async () => {
      let me = null;
      try {
        me = await db.auth.me();
      } catch {
        me = null;
      }
      if (!alive) return;
      if (!me) {
        setStatus("anon");
        return;
      }
      setUser(me);
      if (me.role !== "admin") {
        setStatus("denied");
        return;
      }
      try {
        const rows = await db.entities.Invitation.list("-created_date", 1);
        if (alive && rows?.[0]) {
          setRecordId(rows[0].id);
          setDraft(mergeInvitation(rows[0]));
        }
      } catch {
        /* start from defaults */
      }
      try {
        const shots = await db.entities.CouplePhoto.list("-created_date", 200);
        if (alive) setPhotos(Array.isArray(shots) ? shots : []);
      } catch {
        /* no photos yet */
      }
      if (alive) setStatus("ready");
    })();
    return () => {
      alive = false;
    };
  }, []);

  const reloadPhotos = async () => {
    const shots = await db.entities.CouplePhoto.list("-created_date", 200);
    setPhotos(Array.isArray(shots) ? shots : []);
  };

  const patch = (partial) => setDraft((d) => ({ ...d, ...partial }));

  const save = async () => {
    setSaving(true);
    setToast("");
    try {
      const payload = JSON.parse(JSON.stringify(draft));
      ["id", "created_date", "updated_date", "created_by_id", "created_by"].forEach((k) => delete payload[k]);
      if (recordId) {
        await db.entities.Invitation.update(recordId, payload);
      } else {
        const created = await db.entities.Invitation.create(payload);
        setRecordId(created.id);
      }
      setToast("Saved — the invitation is updated for every guest.");
    } catch (e) {
      setToast(e?.message || "Could not save your changes.");
    }
    setSaving(false);
    setTimeout(() => setToast(""), 3500);
  };

  if (status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-paper">
        <Loader2 className="h-6 w-6 animate-spin text-sindoor" />
      </div>
    );
  }

  if (status === "anon") {
    return (
      <Gate title="Family Studio">
        <p className="text-[13.5px] leading-relaxed text-maroon/65">
          This studio is where the families edit the invitation, upload photographs and read the guest replies. Please
          sign in with the family's admin account to continue.
        </p>
        <div className="mt-6 space-y-3">
          <button
            type="button"
            onClick={() => db.auth.redirectToLogin("/admin")}
            className="w-full rounded-full bg-[linear-gradient(100deg,#8f2417,#b82a1d_45%,#8f2417)] px-5 py-3 font-display text-[10px] uppercase tracking-[0.26em] text-paper"
          >
            Sign in to the studio
          </button>
          <Link
            to="/"
            className="block font-display text-[9.5px] uppercase tracking-[0.24em] text-maroon/50 hover:text-maroon"
          >
            Back to the invitation
          </Link>
        </div>
      </Gate>
    );
  }

  if (status === "denied") {
    return (
      <Gate title="Admin access needed">
        <p className="text-[13.5px] leading-relaxed text-maroon/65">
          You are signed in as <span className="text-sindoor">{user?.email}</span>, but editing the invitation needs an
          admin account. Ask the family to make this account an admin from the app's users page.
        </p>
        <div className="mt-6 space-y-3">
          <GhostButton onClick={() => db.auth.logout("/")}>
            <LogOut className="h-3 w-3" /> Sign out
          </GhostButton>
          <Link
            to="/"
            className="block font-display text-[9.5px] uppercase tracking-[0.24em] text-maroon/50 hover:text-maroon"
          >
            Back to the invitation
          </Link>
        </div>
      </Gate>
    );
  }

  return (
    <div className="min-h-screen bg-paper">
      <header className="sticky top-0 z-30 border-b border-gold/30 bg-paper/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-gold/50 text-maroon/70 transition hover:bg-gold/10"
              aria-label="Back to the invitation"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <div>
              <p className="font-display text-[8.5px] uppercase tracking-[0.34em] text-sindoor/80">Family Studio</p>
              <h1 className="font-heading text-[17px] leading-tight text-maroon">
                {draft.bride_name} &amp; {draft.groom_name}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {toast && (
              <span className="flex items-center gap-1.5 text-[11.5px] text-leaf">
                <Check className="h-3 w-3" /> {toast}
              </span>
            )}
            <Link
              to="/"
              className="hidden rounded-full border border-gold/50 px-4 py-2 font-display text-[9px] uppercase tracking-[0.22em] text-maroon/70 transition hover:bg-gold/10 sm:inline-block"
            >
              View invitation
            </Link>
            <GhostButton onClick={save} tone="solid" disabled={saving}>
              {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
              {saving ? "Saving" : "Save changes"}
            </GhostButton>
          </div>
        </div>

        <div className="mx-auto max-w-6xl overflow-x-auto px-2 pb-2 sm:px-4">
          <div className="flex gap-1">
            {TABS.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setTab(t.key)}
                className={`shrink-0 rounded-full px-3.5 py-1.5 font-display text-[9px] uppercase tracking-[0.2em] transition ${
                  tab === t.key
                    ? "bg-sindoor/10 text-sindoor"
                    : "text-maroon/50 hover:bg-gold/10 hover:text-maroon/80"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-5 px-4 py-6 sm:px-6 sm:py-8">
        {tab === "couple" && <CouplePanel draft={draft} patch={patch} />}
        {tab === "families" && <FamiliesPanel draft={draft} patch={patch} />}
        {tab === "events" && <EventsPanel draft={draft} patch={patch} />}
        {tab === "journey" && <JourneyPanel draft={draft} patch={patch} />}
        {tab === "story" && <StoryPanel draft={draft} patch={patch} />}
        {tab === "words" && <WordsPanel draft={draft} patch={patch} />}
        {tab === "photos" && <PhotosManager photos={photos} onChanged={reloadPhotos} />}
        {tab === "media" && <MediaPanel draft={draft} patch={patch} />}
        {tab === "replies" && <RepliesPanel />}

        <div className="flex flex-col items-center gap-3 pb-8 pt-2">
          <GhostButton onClick={save} tone="solid" disabled={saving}>
            {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
            {saving ? "Saving" : "Save changes"}
          </GhostButton>
          <p className="text-center font-display text-[9px] uppercase tracking-[0.2em] text-maroon/35">
            Photographs save instantly · text changes save on this button
          </p>
          <button
            type="button"
            onClick={() => db.auth.logout("/")}
            className="inline-flex items-center gap-1.5 font-display text-[9px] uppercase tracking-[0.24em] text-maroon/35 hover:text-maroon/70"
          >
            <LogOut className="h-3 w-3" /> Sign out
          </button>
        </div>
      </main>
    </div>
  );
}