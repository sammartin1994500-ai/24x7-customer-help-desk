// Local preview adapter. Connect the real Base44 SDK for persistent backend features.
const localPreviewDb = {
  app: { getPublicSettings: async () => ({ id: "local-preview", public_settings: {} }) },
  auth: { isAuthenticated: async () => false, me: async () => null, logout: () => {}, redirectToLogin: () => {} },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], list: async () => [], get: async () => null, create: async (value = {}) => ({ ...value, id: "local-preview" }), update: async (_id, value = {}) => value, delete: async () => ({}), subscribe: () => () => {} }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: "" }) } },
};
export const db = globalThis.__B44_DB__ || localPreviewDb;
export const base44 = db;
export default db;
