const db = globalThis.__B44_DB__ || {
  app: { getPublicSettings: async () => ({ id: "local-preview", public_settings: {} }) },
  auth: {
    isAuthenticated: async () => false,
    me: async () => null,
    logout: () => {},
    redirectToLogin: () => { console.warn("Base44 login is unavailable in local preview."); },
  },
  entities: new Proxy({}, {
    get: () => ({
      filter: async () => [],
      list: async () => [],
      get: async () => null,
      create: async (value = {}) => ({ ...value, id: "local-preview" }),
      update: async (_id, value = {}) => value,
      delete: async () => ({}),
      subscribe: () => () => {},
    }),
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: "" }) } },
};

import { useEffect, useState } from "react";

import { defaultInvitation, mergeInvitation } from "@/lib/invitationDefaults";

/**
 * Loads the single Invitation record + every uploaded photograph.
 * Live-subscribes so admin edits appear on the public invitation immediately.
 */
export default function useInvitationData() {
  const [data, setData] = useState(defaultInvitation);
  const [photos, setPhotos] = useState([]);
  const [recordId, setRecordId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const rows = await db.entities.Invitation.list("-created_date", 1);
        if (alive && rows?.[0]) {
          setRecordId(rows[0].id);
          setData(mergeInvitation(rows[0]));
        }
      } catch {
        /* invitation falls back to defaults */
      }
      try {
        const shots = await db.entities.CouplePhoto.list("-created_date", 200);
        if (alive) setPhotos(Array.isArray(shots) ? shots : []);
      } catch {
        /* no photographs yet */
      }
      if (alive) setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const unsubInv = db.entities.Invitation.subscribe((event) => {
      if (event.type === "delete") return;
      setRecordId(event.data.id);
      setData(mergeInvitation(event.data));
    });
    const unsubPhotos = db.entities.CouplePhoto.subscribe((event) => {
      setPhotos((prev) => {
        if (event.type === "delete") return prev.filter((p) => p.id !== event.data.id);
        const exists = prev.some((p) => p.id === event.data.id);
        return exists ? prev.map((p) => (p.id === event.data.id ? event.data : p)) : [...prev, event.data];
      });
    });
    return () => {
      unsubInv?.();
      unsubPhotos?.();
    };
  }, []);

  return { data, photos, recordId, loading };
}